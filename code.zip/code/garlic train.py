import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.cross_decomposition import PLSRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from deap import base, creator, tools, algorithms
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Dense, Dropout, Conv1D, Flatten, MaxPooling1D, BatchNormalization
from tensorflow.keras.callbacks import ReduceLROnPlateau, EarlyStopping
from tensorflow.keras.layers import Input, Add, Activation
import xgboost as xgb
import tensorflow as tf
import random
from sklearn.decomposition import PCA

import matplotlib.pyplot as plt
from scipy.signal import savgol_filter

random.seed(42)
np.random.seed(42)

tf.random.set_seed(42)


# 1. 加载数据
file_path = "Test/garlic.xlsx"
df = pd.read_excel(file_path, sheet_name="Sheet2")

# 2. 数据预处理
# 特征和目标变量
X = df[[f"Band {i}" for i in range(1, 151)]].values  # 150个波段
y = df["weight"].values  # 目标变量

# 对时间和Index进行编码处理
time_encoded = pd.Categorical(df["TIME"]).codes
index_encoded = pd.Categorical(df["Index"]).codes
X = np.hstack((X, time_encoded[:, None], index_encoded[:, None]))  # 将时间和Index作为额外特征
# 数据归一化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# 3. 遗传算法选择波段
def evaluate_fitness(individual, X, y, penalty_weight=0.01, diversity_weight=0.01, min_bands=5):
    """Fitness function with diversity constraint."""
    selected_bands = np.where(individual)[0]
    if len(selected_bands) < min_bands:  # 限制选择的最少波段数
        return float('inf'),  # 防止选择波段过少
    if np.var(X[:, selected_bands], axis=0).min() == 0:  # 确保选择的波段具有非零方差
        return float('inf'),
    X_selected = X[:, selected_bands]
    if len(np.unique(selected_bands)) > 1 and np.sum(X_selected, axis=0).min() == 0:  # 加入对特征贡献的约束
        return float('inf'),
    model = RandomForestRegressor(n_estimators=50, random_state=42)
    model.fit(X_selected, y)
    predictions = model.predict(X_selected)
    mse = mean_squared_error(y, predictions)
    # 增加多样性惩罚和选择数量惩罚
    diversity_penalty = diversity_weight * len(np.unique(selected_bands))
    penalty = penalty_weight * len(selected_bands)
    return mse + penalty + diversity_penalty,

def genetic_band_selection(X, y, n_generations=40, n_population=60):
    """Perform genetic algorithm for band selection."""
    n_features = X.shape[1]
    creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
    creator.create("Individual", list, fitness=creator.FitnessMin)
    toolbox = base.Toolbox()
    toolbox.register("attr_bool", lambda: np.random.randint(0, 2) if np.var(X[:, np.random.randint(0, 2)]) > 0 else 0)
    toolbox.register("individual", tools.initRepeat, creator.Individual, toolbox.attr_bool, n_features)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)
    toolbox.register("evaluate", evaluate_fitness, X=X, y=y)
    toolbox.register("mate", tools.cxTwoPoint)
    toolbox.register("mutate", tools.mutFlipBit, indpb=0.3)
    toolbox.register("select", tools.selTournament, tournsize=3)
    population = toolbox.population(n=n_population)
    algorithms.eaSimple(population, toolbox, cxpb=0.845, mutpb=0.3, ngen=n_generations, verbose=True)
    best_individual = tools.selBest(population, k=1)[0]
    return np.where(best_individual)[0]

# 使用遗传算法选择波段
selected_bands = genetic_band_selection(X_train, y_train)
print(f"Selected bands: {selected_bands}")

# 使用选定的波段
X_train_selected = X_train[:, selected_bands]
X_test_selected = X_test[:, selected_bands]

# # 3. PCA 降维
# # 替换遗传算法，用 PCA 对波段降维
# n_components = 20  # 设置主成分数量，可调整
# pca = PCA(n_components=n_components)
# X_train_pca = pca.fit_transform(X_train)
# X_test_pca = pca.transform(X_test)
#
# # 打印解释方差比例
# explained_variance_ratio = pca.explained_variance_ratio_
# print(f"Explained Variance Ratio for each component: {explained_variance_ratio}")
# print(f"Total Explained Variance: {np.sum(explained_variance_ratio):.2f}")
#
# # 使用降维后的 PCA 特征代替波段选择后的特征
# X_train_selected = X_train_pca
# X_test_selected = X_test_pca


# 4. 模型设计与训练

# (a) 随机森林回归
rf_model = RandomForestRegressor(n_estimators=150, random_state=42) #GA:150,PCA:100
rf_model.fit(X_train_selected, y_train)
rf_predictions = rf_model.predict(X_test_selected)
rf_mse = mean_squared_error(y_test, rf_predictions)
rf_rmse = np.sqrt(rf_mse)
rf_r2 = r2_score(y_test, rf_predictions)
print(f"随机森林回归 - RMSE: {rf_rmse:.4f}, R²: {rf_r2:.4f}")

# (b) PLS回归
pls_model = PLSRegression(n_components=15) # GA:10, pca:15
# pls_model.fit(X_train_selected, y_train) # GA
# pls_predictions = pls_model.predict(X_test_selected).flatten() # GA
pls_model.fit(X_train, y_train) # pca
pls_predictions = pls_model.predict(X_test).flatten() # pca
pls_mse = mean_squared_error(y_test, pls_predictions)
pls_rmse = np.sqrt(pls_mse)
pls_r2 = r2_score(y_test, pls_predictions)
print(f"PLS回归 - RMSE: {pls_rmse:.4f}, R²: {pls_r2:.4f}")

# (c) MLP模型
mlp_model = Sequential([
    Dense(1024, activation='relu', input_shape=(X_train_selected.shape[1],)),
    Dropout(0.4),
    Dense(512, activation='relu'),
    Dropout(0.3),
    Dense(256, activation='relu'),
    Dropout(0.2),
    Dense(128, activation='relu'),
    Dropout(0.2),
    Dense(64, activation='relu'),
    Dropout(0.2),
    Dense(32, activation='relu'),
    Dropout(0.2),
    # Dense(16, activation='relu'),
    # Dropout(0.2),
    Dense(1)
])
mlp_model.compile(optimizer='adam', loss='mse', metrics=['mae'])

# 添加学习率调度器和早停
callbacks = [
    ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, min_lr=1e-6),
    EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
]

mlp_model.fit(X_train_selected, y_train, validation_split=0.2, epochs=110, batch_size=16, callbacks=callbacks, verbose=1)

mlp_predictions = mlp_model.predict(X_test_selected).flatten()
mlp_mse = mean_squared_error(y_test, mlp_predictions)
mlp_rmse = np.sqrt(mlp_mse)
mlp_r2 = r2_score(y_test, mlp_predictions)
print(f"改进后的 MLP模型 - RMSE: {mlp_rmse:.4f}, R²: {mlp_r2:.4f}")

# (d) resNet模型
# 残差块的定义
def residual_block(input_tensor, filters, kernel_size=3, stride=1):
    """构建一个残差块"""
    # 第一层卷积
    x = Conv1D(filters, kernel_size, strides=stride, padding='same')(input_tensor)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)

    # 第二层卷积
    x = Conv1D(filters, kernel_size, strides=1, padding='same')(x)
    x = BatchNormalization()(x)

    # 添加跳跃连接
    shortcut = input_tensor
    if stride != 1 or input_tensor.shape[-1] != filters:
        shortcut = Conv1D(filters, kernel_size=1, strides=stride, padding='same')(input_tensor)
        shortcut = BatchNormalization()(shortcut)
    x = Add()([x, shortcut])
    x = Activation('relu')(x)
    return x

# 构建 ResNet 模型
def build_resnet(input_shape, num_residual_blocks, filters):
    """构建 ResNet 模型"""
    inputs = Input(shape=input_shape)
    x = Conv1D(filters, kernel_size=5, strides=2, padding='same')(inputs)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = MaxPooling1D(pool_size=3, strides=2, padding='same')(x)

    for i in range(num_residual_blocks):
        x = residual_block(x, filters)

    x = Flatten()(x)
    # x = Dense(256, activation='relu')(x)
    # x = Dropout(0.3)(x)
    x = Dense(256, activation='relu')(x)
    x = Dropout(0.2)(x)
    x = Dense(128, activation='relu')(x)
    x = Dropout(0.2)(x)
    outputs = Dense(1)(x)
    model = Model(inputs, outputs)
    return model

# 构建 ResNet 模型实例
resnet_model = build_resnet(input_shape=(X_train_selected.shape[1], 1), num_residual_blocks=5, filters=64)

# 编译 ResNet 模型
resnet_model.compile(optimizer='adam', loss='mse', metrics=['mae'])

# 添加学习率调度器和早停
callbacks = [
    ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, min_lr=1e-6),
    EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
]

# 训练 ResNet 模型
resnet_model.fit(X_train_selected[..., np.newaxis], y_train, validation_split=0.2, epochs=300, batch_size=16, callbacks=callbacks, verbose=1)

# 测试 ResNet 模型
resnet_predictions = resnet_model.predict(X_test_selected[..., np.newaxis]).flatten()
resnet_mse = mean_squared_error(y_test, resnet_predictions)
resnet_rmse = np.sqrt(resnet_mse)
resnet_r2 = r2_score(y_test, resnet_predictions)
print(f"ResNet模型 - RMSE: {resnet_rmse:.4f}, R²: {resnet_r2:.4f}")

# (e) XGboost 模型
# 创建 XGBoost 数据格式
dtrain = xgb.DMatrix(X_train_selected, label=y_train)
dtest = xgb.DMatrix(X_test_selected, label=y_test)

# 设置 XGBoost 参数
xgb_params = {
    "objective": "reg:squarederror",  # 回归任务
    "eval_metric": "rmse",           # 使用 RMSE 作为评估指标
    "max_depth": 5,                  # 树的最大深度
    "eta": 0.09,                      # 学习率
    "subsample": 0.8,                # 数据采样比例
    "colsample_bytree": 0.8          # 特征采样比例
}

# 训练 XGBoost 模型
xgb_model = xgb.train(
    params=xgb_params,
    dtrain=dtrain,
    num_boost_round=240,            # 迭代次数
    evals=[(dtrain, "train"), (dtest, "test")],
    early_stopping_rounds=10        # 早停
)

# 使用 XGBoost 预测
xgb_predictions = xgb_model.predict(dtest)
xgb_mse = mean_squared_error(y_test, xgb_predictions)
xgb_r2 = r2_score(y_test, xgb_predictions)
xgb_rmse = np.sqrt(xgb_mse)

print(f"XGBoost模型 - RMSE: {xgb_rmse:.4f}, R²: {xgb_r2:.4f}")

# 5. 输出结果对比
results = pd.DataFrame({
    "Model": ["Random Forest", "PLSR", "MLP", "ResNet", "XGBoost"],
    "MSE": [rf_mse, pls_mse, mlp_mse, resnet_mse, xgb_mse],
    "RMSE": [rf_rmse, pls_rmse, mlp_rmse, resnet_rmse, xgb_rmse],
    "R²": [rf_r2, pls_r2, mlp_r2, resnet_r2, xgb_r2]
})

print(results)

# 保存结果到 Excel
results.to_excel("model_comparison_results_with_xgboost.xlsx", index=False)

# # 6 可视化
# file_path = "Test/MMM.xlsx"  # 替换为您的文件路径
# data = pd.read_excel(file_path, sheet_name="Sheet5")
#
# # 计算每个分组的均值
# band_columns = [f'Band {i}' for i in range(1, 151)]
# group1_mean = data.iloc[:11][band_columns].mean(axis=0)
# group2_mean = data.iloc[11:21][band_columns].mean(axis=0)
# group3_mean = data.iloc[21:][band_columns].mean(axis=0)
# # Smooth the lines using Savitzky-Golay filter
# window_length = 11  # Must be odd, controls the smoothness
# polyorder = 2       # Polynomial order for smoothing
# group1_smooth = savgol_filter(group1_mean, window_length, polyorder)
# group2_smooth = savgol_filter(group2_mean, window_length, polyorder)
# group3_smooth = savgol_filter(group3_mean, window_length, polyorder)
#
# # Plot the three lines
# plt.figure(figsize=(12, 6))
# plt.plot(range(1, 151), group1_smooth, label='Group 1 ', linewidth=2, linestyle='-')
# plt.plot(range(1, 151), group2_smooth, label='Group 2 ', linewidth=2, linestyle='--')
# plt.plot(range(1, 151), group3_smooth, label='Group 3 ', linewidth=2, linestyle='-.')
#
# # Add labels and legend
# plt.title('5.31 Mean Reflectance Across Bands for Three Groups')
# plt.xlabel('Band Number')
# plt.ylabel('Mean Reflectance')
# plt.legend()
# plt.grid(True)
#
# # Show the plot
# plt.show()
