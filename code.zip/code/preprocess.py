import numpy as np
import matplotlib.pyplot as plt
from spectral import io, open_image
import os
import pandas as pd
from scipy.signal import savgol_filter


# 读取 HSI 文件
def read_hsi_file(hdr_path):
    """
    读取 .hdr 文件并提取为 numpy 数组，同时提取波长信息。

    参数:
    - hdr_path: HSI 文件的头文件路径 (.hdr)

    返回:
    - data: 高光谱图像数据 (numpy 数组)
    - wavelengths: 波段对应的波长信息
    """
    # 自动推断对应的 .hsi 数据文件路径
    data_path = hdr_path.replace('.hdr', '')

    # 检查数据文件是否存在
    if not os.path.exists(data_path):
        raise FileNotFoundError(f"Data file {data_path} not found. Please ensure the .hsi file is present.")

    # 打开 HSI 文件
    img = io.envi.open(hdr_path, image=data_path)

    # 加载高光谱数据为 numpy 数组
    data = img.load()

    # 提取波长信息
    wavelengths = np.array(img.bands.centers)  # 获取波长信息

    return data, wavelengths


# Savitzky-Golay 滤波降噪
def denoise_hsi_data(image, window_length=11, polyorder=2):
    """
    参数:
    - image: 输入的高光谱图像数据，三维数组 (height, width, bands)
    - window_length: 滤波窗口长度，必须是奇数
    - polyorder: 多项式拟合的阶数
    """
    # 对每个像素点的光谱进行 Savitzky-Golay 滤波
    image_smoothed = savgol_filter(image, window_length=window_length, polyorder=polyorder, axis=2)
    return image_smoothed


# 归一化
def normalize_hsi(image):
    """
    将高光谱数据归一化到 0-1 范围
    """
    return (image - np.min(image)) / (np.max(image) - np.min(image) + 1e-6)


# 辐射校正函数
def apply_radiometric_correction(image):
    """
    使用给定的辐射校正公式 y = 1.7266x - 5.0584 4.22 对高光谱图像进行校正
    使用给定的辐射校正公式 y = 0.2318 * x^1.0955 + -2.6383 5.13 对高光谱图像进行校正
    使用给定的辐射校正公式 y = 0.3855x − 4.9184 5.21 对高光谱图像进行校正
    使用给定的辐射校正公式 y = 0.2757 * x^1.0580 + -3.2126 5.31 对高光谱图像进行校正
    """
    return 0.3855 * image - 4.9184
    # return 0.2318 * np.power(image, 1.0955) - 2.6383


# 植被指数计算
def calculate_indices(image, wavelengths):
    # 提取特定波段的波长范围，选择50 nm范围内的均值
    # def mean_band(image, wavelengths, start, end):
    #     band_indices = np.where((wavelengths >= start) & (wavelengths <= end))[0]
    #     return image[:, :, band_indices].mean(axis=2)
    def mean_band(averages, wavelengths, start, end):
        band_indices = np.where((wavelengths >= start) & (wavelengths <= end))[0]
        if len(band_indices) == 0:
            raise ValueError(f"No bands found in the range {start}-{end} nm.")
        return averages[band_indices].mean()

    red_band = mean_band(image, wavelengths, 640, 680)  # 红光 635-685 nm
    nir_band = mean_band(image, wavelengths, 830, 870)  # 近红外 825-875 nm
    blue_band = mean_band(image, wavelengths, 450, 490)  # 蓝光 445-495 nm
    green_band = mean_band(image, wavelengths, 530, 570)  # 绿光 525-575 nm
    red_edge_band = mean_band(image, wavelengths, 700, 740)  # 红边 695-745 nm
    # red_band = mean_band(image, wavelengths, 650, 670)  # 红光 635-685 nm
    # nir_band = mean_band(image, wavelengths, 840, 860)  # 近红外 825-875 nm
    # blue_band = mean_band(image, wavelengths, 460, 480)  # 蓝光 445-495 nm
    # green_band = mean_band(image, wavelengths, 540, 560)  # 绿光 525-575 nm
    # red_edge_band = mean_band(image, wavelengths, 710, 730)  # 红边 695-745 nm


    # 计算指数，并取整个区域的平均值
    indices = {
        "CIRed": np.mean(nir_band / (red_band + 1e-6) - 1),
        "CVI": np.mean((nir_band * red_band) / (green_band ** 2 + 1e-6)),
        "EVI": np.mean(2.5 * (nir_band - red_band) / (nir_band + 6 * red_band - 7.5 * blue_band + 1)),
        "EVI2": np.mean(2.5 * (nir_band - red_band) / (nir_band + 2.4 * red_band + 1)),
        "GCI": np.mean(nir_band / (green_band + 1e-6) - 1),
        "GNDVI": np.mean((nir_band - green_band) / (nir_band + green_band + 1e-6)),
        "GRVI": np.mean((green_band - red_band) / (green_band + red_band + 1e-6)),
        "MEXG": np.mean(1.262 * green_band - 0.884 * red_band - 0.311 * blue_band),
        "MNGRD": np.mean((green_band - red_band) / (green_band + red_band + blue_band + 1e-6)),
        "NDRE": np.mean((nir_band - red_edge_band) / (nir_band + red_edge_band + 1e-6)),
        "NDVI": np.mean((nir_band - red_band) / (nir_band + red_band + 1e-6)),
        "NGRD": np.mean((green_band - red_band) / (green_band + red_band + 1e-6)),
        "OSAVI": np.mean((nir_band - red_band) / (nir_band + red_band + 0.16 + 1e-6)),
        "PSND": np.mean((nir_band - blue_band) / (nir_band + blue_band + 1e-6)),
        "RDVI": np.mean((nir_band - red_band) / np.sqrt(nir_band + red_band + 1e-6)),
        "RECI": np.mean(nir_band / (red_edge_band + 1e-6) - 1),
        "RVI": np.mean(nir_band / (red_band + 1e-6)),
        "SAVI": np.mean((nir_band - red_band) * (1 + 0.5) / (nir_band + red_band + 0.5 + 1e-6))
    }
    return indices

# 保存植被指数到 Excel 文件
def save_indices_to_excel(indices, filename='hyperspectral/vegetation_indices_results.xlsx'):
    """
    将植被指数保存到 Excel 文件中
    """
    df = pd.DataFrame(list(indices.items()), columns=['Index', 'Value'])
    df.to_excel(filename, index=False)
    print(f"植被指数已保存至 {filename}")


# 计算每个波段的平均值
def calculate_band_averages(image):
    """
    计算每个波段的平均值
    """
    band_averages = np.mean(image, axis=(0, 1))
    band_averages[band_averages < 0] = 0  # 将所有负值裁剪为0
    return band_averages


# 保存波段均值到 Excel 文件
def save_band_averages_to_excel(band_averages, wavelengths, filename='band_averages_results.xlsx'):
    """
    将波段均值保存到 Excel 文件中
    """
    df = pd.DataFrame({
        'Wavelength (nm)': wavelengths,
        'Average Reflectance': band_averages
    })
    df.to_excel(filename, index=False)
    print(f"波段均值已保存至 {filename}")


# 可视化裁剪后的高光谱图像
def visualize_hsi(cropped_image, wavelengths):
    """
    可视化裁剪后的高光谱图像，使用伪RGB组合。
    参数:
    - cropped_image: 裁剪后的高光谱图像数据
    - wavelengths: 波段对应的波长信息
    """
    # 选择接近 RGB 的波段
    red_band = cropped_image[:, :, (wavelengths > 600) & (wavelengths < 700)].mean(axis=2)
    green_band = cropped_image[:, :, (wavelengths > 500) & (wavelengths < 600)].mean(axis=2)
    blue_band = cropped_image[:, :, (wavelengths > 450) & (wavelengths < 500)].mean(axis=2)

    # 组合成 RGB 图像
    rgb_image = np.stack([red_band, green_band, blue_band], axis=-1)

    # 归一化 RGB 图像到 0-1 范围
    rgb_image_normalized = (rgb_image - np.min(rgb_image)) / (np.max(rgb_image) - np.min(rgb_image) + 1e-6)

    # 显示图像
    plt.figure(figsize=(10, 10))
    plt.imshow(rgb_image_normalized)
    plt.title("Cropped Hyperspectral Image (Pseudo-RGB)")
    plt.axis('off')
    plt.show()

# 可视化波段均值
def visualize_band_averages(wavelengths, band_averages):
    """
    可视化波段均值为一条光谱线条。
    参数:
    - wavelengths: 波段对应的波长信息
    - band_averages: 每个波段的平均值
    """
    plt.figure(figsize=(10, 6))
    plt.plot(wavelengths, band_averages, linestyle='-', color='b')
    plt.xlabel('Wavelength (nm)')
    plt.ylabel('Average Reflectance')
    plt.title('Average Reflectance Spectrum')
    plt.grid(True)
    plt.show()

# 主程序逻辑
hdr_file = 'Test/garlic/20240521014756001001_00000000_vnir_Georef.hdr'  # 每次只处理一张高光谱图像

try:
    # 读取高光谱图像数据
    hsi_image, wavelengths = read_hsi_file(hdr_file)
except Exception as e:
    print(e)
    exit(1)

# 裁剪高光谱图像数据（从起点坐标 (x, y) 为 (209, 2667) 开始，69 列，264 行）
x, y = 448, 546
height, width = 248, 67
cropped_hsi_image = hsi_image[y:y + height, x:x + width, :]

# 可视化裁剪后的高光谱图像
visualize_hsi(cropped_hsi_image, wavelengths)

# 辐射校正
corrected_hsi_image = apply_radiometric_correction(cropped_hsi_image)

# 降噪
hsi_image_denoised = denoise_hsi_data(corrected_hsi_image)

# 计算每个波段的平均值 (降噪后)
band_averages = calculate_band_averages(hsi_image_denoised)

# 将波段均值保存到 Excel 文件中
save_band_averages_to_excel(band_averages, wavelengths, filename='Test/band_averages_results.xlsx')

# # 可视化波段均值
# visualize_band_averages(wavelengths, band_averages)

# 计算植被指数
# vegetation_indices = calculate_indices(hsi_image_denoised, wavelengths)
vegetation_indices = calculate_indices(band_averages, wavelengths)

# 保存植被指数到 Excel 文件中
save_indices_to_excel(vegetation_indices, filename='Test/vegetation_indices_results.xlsx')

print("波段均值和植被指数已保存。")
